import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SaveServlet extends HttpServlet
{
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp)
				throws ServletException, IOException
		{
			// TODO Auto-generated method stub
			//super.doPost(req, resp);
			
			String name = req.getParameter("name");
			String email = req.getParameter("email");
			String phone = req.getParameter("phone");
			String message = req.getParameter("message");
			
			Model m =new Model();
			m.setName(name);
			m.setEmail(email);
			m.setPhone(phone);
			m.setMessage(message);
			
			int data = Dao.savedata(m);
			
			if(data>0)
			{
				System.out.println("Inserted");
				
			}
			else
			{
				System.out.println("Fail");
			}
			
		
		}
}
